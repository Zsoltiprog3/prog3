/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import adatbevitel.AdatInput;
import adatbevitel.Beolvasas;
import alaposztalyok.Ajandek;
import alaposztalyok.Angyal;
import alaposztalyok.Global;
import alaposztalyok.Pasztor;
import feluletek.KezeloPanel;
import feluletek.RajzPanel;
import java.awt.Graphics;
import java.awt.Image;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;

/**
 *
 * @author Zsolti
 */
public class Vezerlo {

    private String ajandekEleres = "/adatok/ajandekok.txt";
    private KezeloPanel kezeloPanel;
    private RajzPanel rajzPanel;
    private Angyal angyal;
    private Pasztor pasztor;
    private List<Pasztor> pasztorLista;
    private int sorszam;
    private Image csaladkep = new ImageIcon(this.getClass().getResource("/adatok/nativity.gif")).getImage();
    private Ajandek ajandek;

    public Vezerlo(KezeloPanel kezeloPanel, RajzPanel rajzPanel) {
        this.kezeloPanel = kezeloPanel;
        this.rajzPanel = rajzPanel;
    }
    
    

    public void beolvasas() {
        try {
            AdatInput adatInput = new Beolvasas(ajandekEleres);
            DefaultComboBoxModel<Ajandek> ajandekCmb = adatInput.ajandekCmb();
            kezeloPanel.kiir(ajandekCmb);
        } catch (Exception ex) {
            Logger.getLogger(Vezerlo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void frissit() {
        rajzPanel.repaint();
    }

    public void szuletes() {

        Image kep = new ImageIcon(this.getClass().getResource("/adatok/angyal.gif")).getImage();
        int kezdoX= 350;
        int kezdoY = 100;
        int kepszelesseg = Global.ANGYAL_SZELESSEG;
        int kepmagassag = Global.ANGYAL_MAGASSAG;
        long ido = Global.ANGYAL_PIHENESI_IDO;  
        angyal = new Angyal(kep, kezdoX, kezdoY, kepszelesseg, kepmagassag, this, ido); 
        angyal.beallitas((int) (Math.random()*5));
        Angyal.setTuzX(Global.ANGYAL_ERKEZO_X);
        Angyal.setTuzY(Global.ANGYAL_ERKEZO_Y);
        frissit();
        angyal.start();
    }

    public void rajzolas(Graphics g) {
        if(angyal !=null){
          angyal.rajzolas(g);
        }
        if (pasztor !=null) {
            pasztor.rajzolas(g);
        }

        g.drawImage(csaladkep, Global.CSALADKEP_BAL_FELSO_X, Global.CSALADKEP_BAL_FELSO_Y, Global.CSALADKEP_SZELESSEG, Global.CSALADKEP_MAGASSAG, null);
    }

    public void pasztorIndit(int x, int y) {
        if (x < Global.PASZTOR_TUZ_SZELESSEG && y > Global.PASZTOR_TUZ_MAGASSAG) {
            Image kep = new ImageIcon(this.getClass().getResource("/adatok/pasztor.gif")).getImage();
            long ido = (long) (Math.random() * (Global.PASZTOR_PIHENESI_IDO_FELSO - Global.PASZTOR_PIHENESI_IDO_ALSO) + Global.PASZTOR_PIHENESI_IDO_ALSO);
            Pasztor.setErkezoX(Global.PASZTOR_ERKEZO_X);
            sorszam++;
            if (sorszam<=Global.PASZTOROK_SZAMA) {
                pasztor = new Pasztor(kep, Global.PASZTOR_INDUlO_X, Global.PASZTOR_INDULO_FEJMAGASSAG, Global.PASZTOR_SZELESSEG,
                    Global.PASZTOR_MAGASSAG, this, ido, Global.PASZTOR_NEV,ajandek);
                pasztor.beallitas(10);
                pasztorLista = new ArrayList<>();
                pasztorLista.add(pasztor);
                kezeloPanel.listaba(pasztorLista);
                for (Pasztor pasztor : pasztorLista) {
                    Thread szal = new Thread(pasztor);
                    szal.start();
                }
                
//               System.out.println(pasztor.getNev()+sorszam);
            }
        }
    }

    public void kivalasztottAjendek(Ajandek ajandek) {
        ajandek = new Ajandek(ajandek.toString());
        this.ajandek = ajandek;
        
    }
    
    public void tisztit() {
        pasztor = null;
        angyal = null;
        csaladkep = null;
    }
    
}
