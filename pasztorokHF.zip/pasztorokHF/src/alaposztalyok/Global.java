/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alaposztalyok;

/**
 *
 * @author :)
 */
public class Global {
    
    public static final int ANGYAL_SZELESSEG = 90;
    public static final int ANGYAL_MAGASSAG = 90;

   // a jobboldali panel bal alsó sarkához képest megadott távolságok    
    public static final int ANGYAL_ERKEZO_X = 200;
    public static final int ANGYAL_ERKEZO_Y = 250;    
    
    public static final long ANGYAL_PIHENESI_IDO = 20;
    
    public static final int PASZTOR_SZELESSEG = 80;
    public static final int PASZTOR_MAGASSAG = 140;
    
    // Ezek közötti random ideig pihennek a pásztorok
    public static final long PASZTOR_PIHENESI_IDO_ALSO = 20;
    public static final long PASZTOR_PIHENESI_IDO_FELSO = 30;  
    
    public static final String PASZTOR_NEV = "Pásztor";
    
    public static final int PASZTOROK_SZAMA = 10;
    
    // a jobboldali panel bal alsó sarkához képest megadott távolságok
    public static final int PASZTOR_TUZ_SZELESSEG = 60;
    public static final int PASZTOR_TUZ_MAGASSAG = 60;    
    
    // a jobboldali panel bal alsó sarkához képest megadott távolságok
    public static final int PASZTOR_INDUlO_X = 100;
    public static final int PASZTOR_INDULO_FEJMAGASSAG = 250;    
    public static final int PASZTOR_ERKEZO_X = 550;
    
    // A jobboldali panel tényleges koordinátáinak helye
    public static final int CSALADKEP_BAL_FELSO_X = 600;
    public static final int CSALADKEP_BAL_FELSO_Y = 250;    
    
    public static int CSALADKEP_SZELESSEG = 150;
    public static int CSALADKEP_MAGASSAG = 150;    
    
}
