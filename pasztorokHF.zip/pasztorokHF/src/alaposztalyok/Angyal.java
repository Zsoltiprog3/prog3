/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alaposztalyok;

import controller.Vezerlo;
import java.awt.Graphics;
import java.awt.Image;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Zsolti
 */
public class Angyal extends Thread{

    private Image img;
    private int kezdoX;
    private int kezdoY;
    private int kepSzelesseg;
    private int kepMagassag;
    private Vezerlo vezerlo;
    private long ido;
    private boolean aktiv;
    private static int tuzX;
    private static int tuzY;
    private int lepeskoz;

    public Angyal(Image img, int kezdoX, int kezdoY, int kepSzelesseg, int kepMagassag, Vezerlo vezerlo, long ido, boolean aktiv) {
        this.img = img;
        this.kezdoX = kezdoX;
        this.kezdoY = kezdoY;
        this.kepSzelesseg = kepSzelesseg;
        this.kepMagassag = kepMagassag;
        this.vezerlo = vezerlo;
        this.ido = ido;
        this.aktiv = aktiv;
    }

    public void beallitas(int lepeskoz) {
        this.lepeskoz = lepeskoz;
    }

    
    public void rajzolas(Graphics g)
    {
        g.drawImage(img, kezdoX, kezdoY, kepSzelesseg, kepMagassag, null);
    }

    @Override
    public void run() {
        try {
            while (aktiv) {
            mozdul();
            frissit();
            pihen();
            }   
        } catch (InterruptedException ex) {
            Logger.getLogger(Angyal.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void mozdul() {
        if (kezdoX != tuzX || kezdoY != tuzY) {
            kezdoX -= lepeskoz;
            kezdoY += lepeskoz;
        }
                
    }

    private void frissit() {
        vezerlo.frissit();
    }

    private void pihen() throws InterruptedException {
        Thread.sleep(ido);
    }

    public Image getImg() {
        return img;
    }

    public void setImg(Image img) {
        this.img = img;
    }

    public static void setTuzX(int tuzX) {
        Angyal.tuzX = tuzX;
    }

    public static void setTuzY(int tuzY) {
        Angyal.tuzY = tuzY;
    }

    public int getKezdoX() {
        return kezdoX;
    }

    public void setKezdoX(int kezdoX) {
        this.kezdoX = kezdoX;
    }

    public int getKezdoY() {
        return kezdoY;
    }

    public void setKezdoY(int kezdoY) {
        this.kezdoY = kezdoY;
    }

    public int getKepSzelesseg() {
        return kepSzelesseg;
    }

    public void setKepSzelesseg(int kepSzelesseg) {
        this.kepSzelesseg = kepSzelesseg;
    }

    public int getKepMagassag() {
        return kepMagassag;
    }

    public void setKepMagassag(int kepMagassag) {
        this.kepMagassag = kepMagassag;
    }

    public Vezerlo getVezerlo() {
        return vezerlo;
    }

    public void setVezerlo(Vezerlo vezerlo) {
        this.vezerlo = vezerlo;
    }

    public long getIdo() {
        return ido;
    }

    public void setIdo(long ido) {
        this.ido = ido;
    }

    
    
}
