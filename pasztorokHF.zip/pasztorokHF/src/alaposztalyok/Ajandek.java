/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alaposztalyok;

/**
 *
 * @author Zsolti
 */
public class Ajandek {
    
    private String ajandekNeve;

    public Ajandek(String ajandekNeve) {
        this.ajandekNeve = ajandekNeve;
    }

    public String getAjandekNeve() {
        return ajandekNeve;
    }

    public void setAjandekNeve(String ajandekNeve) {
        this.ajandekNeve = ajandekNeve;
    }

    @Override
    public String toString() {
        return ajandekNeve;
    }
    
    
}
