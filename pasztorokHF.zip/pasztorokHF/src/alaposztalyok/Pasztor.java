/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alaposztalyok;

import controller.Vezerlo;
import java.awt.Graphics;
import java.awt.Image;
import java.util.logging.Level;
import java.util.logging.Logger;
import sun.font.GraphicComponent;

/**
 *
 * @author Zsolti
 */
public class Pasztor implements Runnable{

    private Image kep;
    private int kezdoX;
    private int kezdoY;
    private int kepSzelesseg;
    private int kepMagassag;
    private Vezerlo vezerlo;
    private long ido;
    private String nev;
    private int lepeskoz;
    private static int erkezoX;
    private int sorszam;
    private static int utolsoSorszam;
    private Ajandek ajandek;

    public Pasztor(Image kep, int kezdoX, int kezdoY, int kepSzelesseg, int kepMagassag, Vezerlo vezerlo, long ido, String nev, Ajandek ajandek) {
        this.kep = kep;
        this.kezdoX = kezdoX;
        this.kezdoY = kezdoY;
        this.kepSzelesseg = kepSzelesseg;
        this.kepMagassag = kepMagassag;
        this.vezerlo = vezerlo;
        this.ido = ido;
        this.nev = nev;
        this.ajandek = ajandek;
        utolsoSorszam++;
        sorszam = utolsoSorszam;
    }

    public void beallitas(int lepeskoz) {
        this.lepeskoz = lepeskoz;
    }
    
    public void rajzolas(Graphics g)
    {
        g.drawImage(kep, kezdoX, kezdoY, kepSzelesseg, kepMagassag, null);
    }

      @Override
    public void run() {
        try {
            while (kezdoX <erkezoX) {
            mozdul();
            frissit();
            pihen(); 
            }
 
        } catch (InterruptedException ex) {
            Logger.getLogger(Angyal.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void mozdul() {

            kezdoX += lepeskoz;

    }

    private void frissit() {
        vezerlo.frissit();
    }

    public static void setErkezoX(int erkezoX) {
        Pasztor.erkezoX = erkezoX;
    }

    private void pihen() throws InterruptedException {
        Thread.sleep(ido);
    }

    public Image getKep() {
        return kep;
    }

    public void setKep(Image kep) {
        this.kep = kep;
    }

    public int getKezdoX() {
        return kezdoX;
    }

    public void setKezdoX(int kezdoX) {
        this.kezdoX = kezdoX;
    }

    public int getKezdoY() {
        return kezdoY;
    }

    public void setKezdoY(int kezdoY) {
        this.kezdoY = kezdoY;
    }

    public int getKepSzelesseg() {
        return kepSzelesseg;
    }

    public void setKepSzelesseg(int kepSzelesseg) {
        this.kepSzelesseg = kepSzelesseg;
    }

    public int getKepMagassag() {
        return kepMagassag;
    }

    public void setKepMagassag(int kepMagassag) {
        this.kepMagassag = kepMagassag;
    }

    public Vezerlo getVezerlo() {
        return vezerlo;
    }

    public void setVezerlo(Vezerlo vezerlo) {
        this.vezerlo = vezerlo;
    }

    public long getIdo() {
        return ido;
    }

    public void setIdo(long ido) {
        this.ido = ido;
    }

    public String getNev() {
        return nev;
    }

    public int getLepeskoz() {
        return lepeskoz;
    }


    public static int getErkezoX() {
        return erkezoX;
    }

    @Override
    public String toString() {
        return sorszam +". "+nev+": "+ajandek;
    }
    
}
