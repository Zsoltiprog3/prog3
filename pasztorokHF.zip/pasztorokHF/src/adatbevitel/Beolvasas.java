/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adatbevitel;

import alaposztalyok.Ajandek;
import java.io.InputStream;
import java.util.Scanner;
import javax.swing.DefaultComboBoxModel;

/**
 *
 * @author Zsolti
 */
public class Beolvasas implements AdatInput{

    private String ajandekEleres;
    private String CHAR_SET="UTF-8";

    public Beolvasas(String ajandekEleres) {
        this.ajandekEleres = ajandekEleres;
    }

    
    
    @Override
    public DefaultComboBoxModel<Ajandek> ajandekCmb() throws Exception {
        DefaultComboBoxModel<Ajandek> ajandekCmb = new DefaultComboBoxModel<>();
        
            String sor;
            Ajandek ajandek;
                
            try (InputStream ins = this.getClass().getResourceAsStream(ajandekEleres);Scanner scan = new Scanner(ins, CHAR_SET)){
            
                while (scan.hasNextLine()) {
                    sor = scan.nextLine();
                    ajandek = new Ajandek(sor);
                    ajandekCmb.addElement(ajandek);
                }
                
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ajandekCmb;
    }
    
}
