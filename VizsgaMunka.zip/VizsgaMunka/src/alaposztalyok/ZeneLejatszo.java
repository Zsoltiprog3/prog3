/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alaposztalyok;

import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import vezerles.Vezerles;

/**
 *
 * @author Zsolti
 */
public class ZeneLejatszo{
    
    private Clip clip;
    
    /**
     * Az intro zene lejátszása
     */
    
    public void kezdoZene(){
    
     try {
            File f = new File("src/adatok/song.wav");
            AudioInputStream audioIn = AudioSystem.getAudioInputStream(f.toURI().toURL());
            zeneinditas(audioIn);
        } catch (LineUnavailableException ex) {
            Logger.getLogger(Vezerles.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Vezerles.class.getName()).log(Level.SEVERE, null, ex);
        } catch (UnsupportedAudioFileException ex) {
            Logger.getLogger(Vezerles.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    /**
     * A jó válasz esetén lejátszandó zene/hang effekt
     */
    
    public void joValasz(){
    
        try {
            File f = new File("src/adatok/jovalasz.wav");
            AudioInputStream audioIn = AudioSystem.getAudioInputStream(f.toURI().toURL());
            zeneinditas(audioIn);
        } catch (LineUnavailableException ex) {
            Logger.getLogger(Vezerles.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Vezerles.class.getName()).log(Level.SEVERE, null, ex);
        } catch (UnsupportedAudioFileException ex) {
            Logger.getLogger(Vezerles.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    }
    
    /**
     * A rossz válasz esetén lejátszandó zene/hang effekt
     */
    
    public void rosszValasz(){
    
        try {
            File f = new File("src/adatok/rosszvalasz.wav");
            AudioInputStream audioIn = AudioSystem.getAudioInputStream(f.toURI().toURL());
            zeneinditas(audioIn);
        } catch (LineUnavailableException ex) {
            Logger.getLogger(Vezerles.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Vezerles.class.getName()).log(Level.SEVERE, null, ex);
        } catch (UnsupportedAudioFileException ex) {
            Logger.getLogger(Vezerles.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    }
    
    /**
     * A zeneíndítása a kódismétlés elkerülése miatt.
     * @param audioIn
     * @throws LineUnavailableException
     * @throws IOException 
     */

    private void zeneinditas(AudioInputStream audioIn) throws LineUnavailableException, IOException {
            clip = AudioSystem.getClip();
            clip.open(audioIn);
            clip.start();
    }


}
