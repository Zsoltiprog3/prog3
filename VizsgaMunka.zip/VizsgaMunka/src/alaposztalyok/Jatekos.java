/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alaposztalyok;

/**
 *
 * @author Zsolti
 */
public class Jatekos {
    
    private String nev;
    private int pontSzam;
    private long jatszottIdo;

    /**
     * A Játékos osztály konstruktora
     * @param nev 
     */
    
    public Jatekos(String nev) {
        this.nev = nev;
    }

    public String getNev() {
        return nev;
    }

    public int getPontSzam() {
        return pontSzam;
    }

    public long getJatszottIdo() {
        return jatszottIdo;
    }
    /**
     * Helyes válasz esetén +1 pont
     */
    
    public void helyesValasz(){
        this.pontSzam++;
    }
    /**
     * A kérdésekre fordított idő számítása
     * @param ido 
     */
    
    public void jatekIdo(long ido){
        this.jatszottIdo += ido;
    }

    @Override
    public String toString() {
        return nev + ": " + pontSzam + " pont " + jatszottIdo + " mp";
    }
    
}
