/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alaposztalyok;

/**
 *
 * @author Zsolti
 */
public class Global {
    
    //Beolvasásra vonatkozó adatok
    public static final String KVIZ_FORRAS = "/adatok/kerdesek.txt";
    public static final String KODOLAS = "UTF-8";
    public static final String SUGO_FORRAS = "/adatok/sugoSzoveg.txt";
    
    //Egy kérdésre vonatkozó adatok
    public static final long KONNYU_JATEKIDO = 60000;
    public static final long NEHEZ_JATEKIDO = 30000;
    
    public static final long SEC = 1000;
    public static final int KERDESSZAM_JATEKALATT = 10;
    public static final int FALS_PER_KERDES = 3;
    
    //Zene források
    public static final String KEZDO_ZENE="src/adatok/song.wav";
    public static final String JO_VALASZ_ZENE="src/adatok/jovalasz.mp3";
    public static final String ROSSZ_VALASZ_ZENE="src/adatok/rosszvalasz.mp3";
}
