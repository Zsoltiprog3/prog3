/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adatInput;

import alaposztalyok.Kerdes;
import java.io.File;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Zsolti
 */
public class Beolvasas implements AdatInput{
    
    private File sugoFajl;
    private String kodolas;
    private Connection kapcsolat;

    /**
     * A beolvasás konstruktora
     * @param sugoFajl
     * @param kodolas
     * @param kapcsolat 
     */
    
    public Beolvasas(File sugoFajl, String kodolas, Connection kapcsolat) {
        this.sugoFajl = sugoFajl;
        this.kodolas = kodolas;
        this.kapcsolat = kapcsolat;
    }

    @Override
    public List<Kerdes> kerdesListaBeolvas() throws Exception {
        List<Kerdes> kerdesLista = new ArrayList<>();        
        String sqlUtasitas = "SELECT * FROM KERDES.KERDES";
        
        if (kapcsolat != null) {
            try (Statement utasitasObj = kapcsolat.createStatement();ResultSet eredmenyHz = utasitasObj.executeQuery(sqlUtasitas)){
                
                String kerd;
                String jovalasz;
                Kerdes kerdes;
                               
                while (eredmenyHz.next()) {
                    List<String> rosszValaszokLista = new ArrayList<>();
                    kerd = eredmenyHz.getString(2);
                    jovalasz = eredmenyHz.getString(3);
                    rosszValaszokLista.clear();
                    rosszValaszokLista.add(eredmenyHz.getString(4));
                    rosszValaszokLista.add(eredmenyHz.getString(5));
                    rosszValaszokLista.add(eredmenyHz.getString(6));

                    kerdes = new Kerdes(kerd, jovalasz, rosszValaszokLista);
                    kerdesLista.add(kerdes);
                }     
                
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return kerdesLista;
    }
    
    
    /**
     * Az interfaceben implementált súgó szöveg beolvasása
     * @return
     * @throws Exception 
     */

    @Override
    public List<String> sugoBeolvas() throws Exception {
        List<String> sugoSzoveg = new ArrayList<>();
        
        try(Scanner scanner = new Scanner(sugoFajl, kodolas)){
            String sor;
            
            while(scanner.hasNextLine()){
                sor = scanner.nextLine();
                
                sugoSzoveg.add(sor);
            }
        }  
        return sugoSzoveg;
    }
}
