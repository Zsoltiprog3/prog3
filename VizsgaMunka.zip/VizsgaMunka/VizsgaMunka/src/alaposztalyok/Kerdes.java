/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alaposztalyok;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Zsolti
 */
public class Kerdes {
    
    private String kerdes;
    private String helyesValasz;
    private List<String> falsValaszok;
    
    /**
     * A Kérdés osztály konstruktora
     * @param kerdes
     * @param helyesValasz
     * @param falsValaszok 
     */

    public Kerdes(String kerdes, String helyesValasz, List<String> falsValaszok) {
        this.kerdes = kerdes;
        this.helyesValasz = helyesValasz;
        this.falsValaszok = falsValaszok;
    }

    public String getKerdes() {
        return kerdes;
    }

    public String getHelyesValasz() {
        return helyesValasz;
    }

    public List<String> getFalsValaszok() {
        return new ArrayList<>(falsValaszok);
    }
    
}
