﻿CREATE TABLE KERDES.KERDES (id int not null primary key, 
                            kerdes varchar(250), 
                            jovalasz varchar(50),rosszvalasz1 varchar(50), rosszvalasz2 varchar(50),
                            rosszvalasz3 varchar(50));


INSERT INTO KERDES.KERDES VALUES(1,'Milyen színűre van festve a rácsos kapu az ismert népdalban?','zöld','piros','kék','lila');
INSERT INTO KERDES.KERDES VALUES(2,'Ki énekli a "Kicsi gesztenye" című dalt?','TNT','Mézga Géza','Popeye','Batman');
INSERT INTO KERDES.KERDES VALUES(3,'Hogy nevezzük valakinek vagy valaminek a gyenge, sebezhető pontját?','Achilles-sarok','Odüsszeusz-térd','Minótaurosz-szem','Medúza-haj');
INSERT INTO KERDES.KERDES VALUES(4,'Hogyan nevezik a fegyelmezetlenül bőbeszédű, fecsegő embert?','szószátyár','szócsászár','szóbetyár','szóhuszár');
INSERT INTO KERDES.KERDES VALUES(5,'Meddig jár a korsó a kútra a közmondás szerint?','amíg el nem törik','amíg oda nem ér','amíg meg nem töltik','amíg el nem tapossák');
INSERT INTO KERDES.KERDES VALUES(6,'Mit csinál az az ember, aki egy viszályban vagy vetélkedésben alul marad?','a rövidebbet húzza','a rövidebbet tolja','a rövidebbet vonja','a rövidebbet rúgja');
INSERT INTO KERDES.KERDES VALUES(7,'Melyik földünk legsósabb tengere az alábbiak közül?','Holt-tenger','Vörös-tenger','Sargasso-tenger','Balti-tenger');
INSERT INTO KERDES.KERDES VALUES(8,'Mit csinál az, aki sifríroz?','titkosírással ír','nem mond igazat','tagoltan olvas','idegen nyelven beszél');
INSERT INTO KERDES.KERDES VALUES(9,'Melyik magyar várost nevezik a leghűségesebb városnak?','Sopron','Eger','Székesfehérvár','Pécs');
INSERT INTO KERDES.KERDES VALUES(10,'Az alábbi színészek közül melyik nem alakította James Bond-ot?','Gregory Peck','George Lazenby','Pierce Brosnan','Timothy Dalton');
INSERT INTO KERDES.KERDES VALUES(11,'Az alábbiak közül milyen élőlény a dingó?','kutyaféle','macskaféle','rágcsáló','ragadozó madár');
INSERT INTO KERDES.KERDES VALUES(12,'Melyik hegységben található Hollókő?','Cserhát','Bükk','Mecsek','Mátra');
INSERT INTO KERDES.KERDES VALUES(13,'Melyik évben rendezték meg az első újkori olimpiát?','1896','1888','1904','1912');
INSERT INTO KERDES.KERDES VALUES(14,'Ki a legutolsó Árpád házi uralkodó?','III. András','IV. László','V. István','IV. Béla');
INSERT INTO KERDES.KERDES VALUES(15,'Az alábbi színészek közül kit neveztek "fapofának"?','Buster Keaton','Charlie Chaplin','Clark Gable','Louis de Funes');
INSERT INTO KERDES.KERDES VALUES(16,'Melyik költő ült a rakodópart alsó kövén és nézte, hogy úszik el a dinnyehéj?','József Attila','Babits Mihály','Ady Endre','Petőfi Sándor');
INSERT INTO KERDES.KERDES VALUES(17,'Melyik egy zsidó ünnep neve az alábbiak közül?','jóm kipúr','fetva','mahájána','talmud');
INSERT INTO KERDES.KERDES VALUES(18,'Az alábbi kémiai elemek közül melyik nem tartozik a nemesgázok csoportjába?','nitrogén','neon','kripton','fluor');
INSERT INTO KERDES.KERDES VALUES(19,'Az alábbiak közül melyik szó elválasztása helytelen?','Wash-ing-ton','Kos-suth','Bat-thyá-ny','Mün-chen');
INSERT INTO KERDES.KERDES VALUES(20,'Mekkora hőmérsékletet nevezünk abszolút nulla foknak?','-273,16 °C','0 °C','-100 °C','273,16 °K');