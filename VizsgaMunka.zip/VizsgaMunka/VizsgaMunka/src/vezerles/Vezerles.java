/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vezerles;

import adatInput.AdatInput;
import adatInput.Beolvasas;
import alaposztalyok.Global;
import alaposztalyok.Jatekos;
import alaposztalyok.Kerdes;
import alaposztalyok.ZeneLejatszo;
import feluletek.InduloPanel;
import feluletek.JatekPanel;
import feluletek.JatekosPanel;
import java.awt.Color;
import java.awt.Image;
import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import static javax.swing.JOptionPane.INFORMATION_MESSAGE;

/**
 *
 * @author Zsolti
 */
public class Vezerles implements Runnable{
    
    private InduloFrame induloFrame;
    private InduloPanel induloPanel;
    private JatekFrame jatekFrame;
    private JatekPanel jatekPanel;
    private JatekosPanel jatekosPanel;

    private SugoFrame sugoFrame;

    private String kodolas;
    private String sugoforras;
    private List<Kerdes> kerdesek = new ArrayList<>();
    private List<String> sugo = new ArrayList<>();

    private List<Kerdes> lehetsegesKerdesek = new ArrayList<>();
    private Kerdes valasztottKerdes;
    private Jatekos jatekos;
    private long kerdesIdo;
    private long masodperc;
    private int kerdesszamPerJatek;
    private int kerdesRosszValaszSzam;
    private boolean valaszolt;
    private boolean szunetel;
    private JButton valaszGombja;
    private String uzenet;
    private Image vagohatter = new ImageIcon(this.getClass().getResource("/kepek/vago.jpg")).getImage();
    private ZeneLejatszo zeneLejatszo = new ZeneLejatszo();
    private Connection kapcsolat;
    private AdatInput adatInput;
    private int OVACIO_SZAM=9;
    private int SIKERES_PONT=5;

    /**
     * A Vezérlő osztály konstruktora
     * @param induloFrame
     * @param induloPanel
     * @param jatekFrame
     * @param jatekPanel
     * @param jatekosPanel 
     */

    public Vezerles(InduloFrame induloFrame, InduloPanel induloPanel, JatekFrame jatekFrame, JatekPanel jatekPanel, JatekosPanel jatekosPanel) {
        this.induloFrame = induloFrame;
        this.induloPanel = induloPanel;
        this.jatekFrame = jatekFrame;
        this.jatekPanel = jatekPanel;
        this.jatekosPanel = jatekosPanel;
    }

/**
 * Konstansok beállítása
 */
    void beallit() {
        kodolas = Global.KODOLAS;
        sugoforras = Global.SUGO_FORRAS;

        masodperc = Global.SEC;
        kerdesszamPerJatek = Global.KERDESSZAM_JATEKALATT;
        kerdesRosszValaszSzam = Global.FALS_PER_KERDES;
    }

/**
 * A frame-k láthatóság beállítása
 */
    public void jatekBeallitas() {
        
        jatekPanel.jatekelemLathatosag();

        induloFrame.setVisible(false);
        jatekFrame.setVisible(true);

        kerdesBeolvasas();
    }

    /**
     * Adatbázisból való beolvasás
     */
    
    private void kerdesBeolvasas() {
        try {
            String sugoEleres = sugoforras;
            File sugoFajl = new File(this.getClass().getResource(sugoEleres).toURI());
            kapcsolat = kapcsolodas();
            adatInput = new Beolvasas(sugoFajl, kodolas, kapcsolat);
            kerdesek = adatInput.kerdesListaBeolvas();
            sugo = adatInput.sugoBeolvas();
        } catch (Exception ex) {
            Logger.getLogger(Vezerles.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    
    public Connection kapcsolodas() throws ClassNotFoundException, SQLException {
        // az adatbázis driver meghatározása
        Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
        // az adatbázis definiálása
        String url = "jdbc:derby://localhost:1527/KERDES";
        // kapcsolodas az adatbázishoz
        return kapcsolat = DriverManager.getConnection(url, "vizsga", "vizsga");
        
    }

    /**
     * Játékos létrehozása, szál indítása
     * @param nev
     * @param kerdesIdo 
     */
    
    public void indulaJatek(String nev, long kerdesIdo) {
        jatekos = new Jatekos(nev);
        this.kerdesIdo = kerdesIdo;
        szunetel = false;
        Thread szal = new Thread(this);
        szal.start();
    }


    @Override
    public void run() {
        jatekPanel.jatekelemLathatosag();
        lehetsegesKerdesek.clear();

        for (Kerdes kerdes : kerdesek) {
            lehetsegesKerdesek.add(kerdes);
        }
        int kovetkezoKerdesIndexe;
        long ido;

        for (int i = 0; i < kerdesszamPerJatek; i++) {
            kovetkezoKerdesIndexe = (int) (Math.random() * lehetsegesKerdesek.size());

            valasztottKerdes = lehetsegesKerdesek.get(kovetkezoKerdesIndexe);
            lehetsegesKerdesek.remove(kovetkezoKerdesIndexe);

            kerdesValaszKiiras();

            ido = kerdesIdo;
            valaszolt = false;

            while (!valaszolt && ido > 0) {
                try {
                    varakozik();
                    jatekosPanel.getLblHatralevoIdo().setText(String.valueOf(ido / 1000) + " sec");
                    ido -= masodperc;
                    Thread.sleep(masodperc);
                } catch (InterruptedException ex) {
                    Logger.getLogger(Vezerles.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

            if (valaszolt) {
                valaszVizsgalat(ido);
            } else {
                jatekos.jatekIdo(kerdesIdo);
            }
        }
        jatekVege();
    }

    /**
     * Kérdés és a hozzá tartozó válasz kiírása a képernyőre
     */

    private void kerdesValaszKiiras() {
        List<String> valaszLehetosegek = new ArrayList<>();
        List<String> lehetValasz = new ArrayList<>();
        for (String fals : valasztottKerdes.getFalsValaszok()) {
            lehetValasz.add(fals);
        }
        int kovetkezoFalsValasz;
        
        valaszLehetosegek.add(valasztottKerdes.getHelyesValasz());

        for (int j = 0; j < kerdesRosszValaszSzam; j++) {
            kovetkezoFalsValasz = (int) (Math.random() * lehetValasz.size());

            valaszLehetosegek.add(lehetValasz.get(kovetkezoFalsValasz));
            lehetValasz.remove(kovetkezoFalsValasz);
        }
        Collections.shuffle(valaszLehetosegek);//Válaszok keverése a gombok között
        jatekPanel.getLblKerdes().setText(valasztottKerdes.getKerdes());
        jatekPanel.getBtnElso().setText(valaszLehetosegek.get(0));
        jatekPanel.getBtnMasodik().setText(valaszLehetosegek.get(1));
        jatekPanel.getBtnHarmadik().setText(valaszLehetosegek.get(2));
        jatekPanel.getBtnNegyedik().setText(valaszLehetosegek.get(3));
    }

/**
 * Szünetel gomb hatása
 */
    private synchronized void varakozik() {
        if (szunetel) {
            try {
                wait();
            } catch (InterruptedException ex) {
                Logger.getLogger(Vezerles.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

/**
 * Folytat gomb hatására felengedi a szálat 
 */
    public synchronized void mukodesValtas() {
        this.szunetel = !this.szunetel;

        if (!this.szunetel) {
            notify();
        }
        jatekPanel.jatekelemLathatosag();
    }

    /**
     * Átveszük a játékos áltál adott választ
     * @param gomb 
     */
    
    public void jatekosValasza(JButton gomb) {
        valaszolt = true;
        valaszGombja = gomb;
    }
/**
 * A játékos által adott válasz vizsgálata és a gombok háttérszínének váltogatása
 * @param ido 
 */
    
    private void valaszVizsgalat(long ido) {
        if (valaszGombja.getText().equals(valasztottKerdes.getHelyesValasz())) {
            valaszGombja.setBackground(Color.green);
            jatekos.helyesValasz();
            zeneLejatszo.joValasz();
            varakozas();
            alapszinre(valaszGombja);
            jatekos.jatekIdo((kerdesIdo - ido) / 1000);
            if (jatekos.getPontSzam() > 0) {
                jatekosPanel.getLblPontszam().setText(jatekos.getPontSzam() + " pont");
            }
            if (jatekos.getPontSzam() > OVACIO_SZAM) {
                zeneLejatszo.gyozelem();
            }
            
        }else{
            valaszGombja.setBackground(Color.red);
            zeneLejatszo.rosszValasz(); 
            varakozas();
            alapszinre(valaszGombja);
        }
        try {
            Thread.sleep(masodperc * 2);
        } catch (InterruptedException ex) {
            Logger.getLogger(Vezerles.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

/**
 * A játék végén mi történjen
 */
    private void jatekVege() {
        jatekosPanel.getLblHatralevoIdo().setText("");
        jatekosPanel.getLblPontszam().setText("");
        jatekosPanel.getTxtNev().setText("");
        jatekosPanel.aktivAllitas();

        jatekPanel.jatekelemLathatosag();
        if (jatekos.getPontSzam() > SIKERES_PONT) {
            uzenet = "Gratulálok " + jatekos.getNev() + "!\nHelyes válaszok száma: " + jatekos.getPontSzam() + "\nFelhasznált idő: " + jatekos.getJatszottIdo() + " sec";
        } else {
            uzenet = "Sajnálom\n"+ "Helyes válaszok száma: " + jatekos.getPontSzam() + "\nFelhasznált idő: " + jatekos.getJatszottIdo() + " sec";
        }
        JOptionPane.showMessageDialog(jatekPanel, uzenet, "Eredmeny", INFORMATION_MESSAGE);
    }
/**
 * Névjegy megjelenítése
 */

    void nevjegyetKerik() {
        JOptionPane.showMessageDialog(jatekPanel, "Készítette: Kis-Tóth Zsolt", "Névjegy", INFORMATION_MESSAGE);
    }
/**
 * Súgó megjelenítése
 */

    void sugotKerik() {
        sugoFrame = new SugoFrame();
        sugoFrame.setTitle("Súgó");
        sugoFrame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);

        for (int i = 1; i < sugo.size(); i++) {
            sugoFrame.getSugoPanel1().getTxtSugo().append(sugo.get(i));
            sugoFrame.getSugoPanel1().getTxtSugo().append("\n");
        }

        sugoFrame.setVisible(true);
    }

    public void gombvalt(JLabel lblHatralevoIdo) {
        lblHatralevoIdo.setText("");
    }
    /**
     * Vége gomb hatására mi történjen
     * @param btnSzunet 
     */

    public void vege(JButton btnSzunet) {
        jatekPanel.hattercsere(vagohatter);
        btnSzunet.setEnabled(false);
    }
/**
 * Intro lejátszása
 */
    public void zeneindit() {
        
        zeneLejatszo.kezdoZene();
    }    
/**
 * Válasz után a gomb hátterének alaphelyzetbe állítása
 * @param valaszGombja 
 */
    private void alapszinre(JButton valaszGombja) {
        
        valaszGombja.setBackground(Color.BLACK);
    }
/**
 * Ennyi ideig lesz más színű a gomb háttere
 */
    private void varakozas() {

        try {
            Thread.sleep(1500);
        } catch (InterruptedException ex) {
            Logger.getLogger(Vezerles.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
/**
 * Vége gomb hatása
 */
    public void vegeUzenet() {
        JOptionPane.showMessageDialog(jatekPanel, jatekos.getPontSzam()+ " pontot ért el", "Vége", INFORMATION_MESSAGE);
    }

    public void zeneleallitas() {
        zeneLejatszo.zeneleallitas();
    }
}
