/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alaposztalyok;

/**
 *
 * @author Zsolti
 */
public class Zeneszam {
    
    private String eloado;
    private String cim;

    public Zeneszam(String eloado, String cim) {
        this.eloado = eloado;
        this.cim = cim;
    }

    public String getEloado() {
        return eloado;
    }

    public String getCim() {
        return cim;
    }

    @Override
    public String toString() {
        return eloado + ": " + cim;
    }
    
    
}
