/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alaposztalyok;

import java.util.Objects;

/**
 *
 * @author Zsolti
 */
public class Balozo{
    

    private String nev;
    private int tancSzam=0;
    private int evfolyam;
    private int sorszam;
    private int penz;
    private int koltseg;
    private static int utolsoSorszam;
    private static boolean TO_STRING=false;
    

    public Balozo(String nev, int evfolyam){
        this.nev = nev;
        this.evfolyam = evfolyam;
        sorszam=utolsoSorszam++;
    }
    
    public int fogyaszt(int koltes)
    {
        if (penz >= koltes) {
             penz -=koltes;
             koltseg += koltes;
        }
        return penz;
    }
    
    public void tancol(){
    
        tancSzam++;
    }


    public String getNev() {
        return nev;
    }

    public int getTancSzam() {
        return tancSzam;
    }

    public int getEvfolyam() {
        return evfolyam;
    }

    public int getSorszam() {
        return sorszam;
    }


    public int getPenz() {
        return penz;
    }

    public static int getUtolsoSorszam() {
        return utolsoSorszam;
    }

    public static void setUtolsoSorszam(int utolsoSorszam) {
        Balozo.utolsoSorszam = utolsoSorszam;
    }

    @Override
    public String toString() {
        
        if (!TO_STRING) {
            return nev;
        }
        return nev + "(" + tancSzam + " tánc, " + koltseg + "Ft)";
    }

    public void setPenz(int penz) {
        this.penz = penz;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 37 * hash + Objects.hashCode(this.nev);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Balozo other = (Balozo) obj;
        if (!Objects.equals(this.nev, other.nev)) {
            return false;
        }
        return true;
    }

    public static void setTO_STRING(boolean TO_STRING) {
        Balozo.TO_STRING = TO_STRING;
    }

    

}
