/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alaposztalyok;

import java.util.Comparator;

/**
 *
 * @author Zsolti
 */
public class Rendezes implements Comparator<Balozo>{

    
    @Override
    public int compare(Balozo o1, Balozo o2) {
        
        return o1.getNev().compareTo(o2.getNev());
    }
}