/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alaposztalyok;

/**
 *
 * @author Zsolti
 */
public class Golya extends Balozo{

    public static double kedvezmenySzazalek;
    
    public Golya(String nev, int evfolyam) {
        super(nev, evfolyam);
    }

    public static double getKedvezmenySzazalek() {
        return kedvezmenySzazalek;
    }

    public static void setKedvezmenySzazalek(double kedvezmenySzazalek) {
        Golya.kedvezmenySzazalek = kedvezmenySzazalek;
    }

    @Override
    public String toString() {
        return super.toString()+" (g)";
    }

    @Override
    public int fogyaszt(int koltes) {
        return (int) (super.fogyaszt(koltes)*(1-kedvezmenySzazalek/100)); 
    }


    
    
    
    
}
