/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adatbevitel;

import alaposztalyok.Balozo;
import alaposztalyok.Golya;
import alaposztalyok.Zeneszam;
import java.io.IOException;
import java.io.InputStream;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultListModel;

/**
 *
 * @author Zsolti
 */
public class Beolvasas implements AdatInput{

    private String zeneEleres;
    private String balozoEleres;
    
    private final String CHAR_SET="UTF-8";

    public Beolvasas(String zeneEleres, String balozoEleres) {
        this.zeneEleres = zeneEleres;
        this.balozoEleres = balozoEleres;
    }
    
    
    
    
    @Override
    public DefaultListModel<Balozo> balozok() throws Exception {
        DefaultListModel<Balozo> balozokModel = new DefaultListModel<>();
        
        try(InputStream ins = this.getClass().getResourceAsStream(balozoEleres);Scanner scan = new Scanner(ins,CHAR_SET);)
        {
            String sor, adatok[];
            Balozo balozo=null;
            //Baranyai János;2
            while (scan.hasNextLine()) {                
                
                sor = scan.nextLine();
                adatok = sor.split(";");
                
                if (Integer.parseInt(adatok[1])==1) {
                    
                    balozo = new Golya(adatok[0], Integer.parseInt(adatok[1]));
                }else{    
                    balozo = new Balozo(adatok[0], Integer.parseInt(adatok[1]));
                }
                
                
                balozokModel.addElement(balozo);
            }
        }catch (IOException ex) {
            Logger.getLogger(Beolvasas.class.getName()).log(Level.SEVERE, null, ex);
        } 
        return balozokModel;
    }

    @Override
    public DefaultListModel<Zeneszam> zeneSzamok() throws Exception {
        DefaultListModel<Zeneszam> zeneSzamModel = new DefaultListModel<>();

        try(InputStream ins = this.getClass().getResourceAsStream(zeneEleres);Scanner scan = new Scanner(ins,CHAR_SET);)
        {
            String sor, adatok[];
            Zeneszam zeneszam=null;
            //Halott pénz;Hello lányok
            while (scan.hasNextLine()) {                
                
                sor = scan.nextLine();
                adatok = sor.split(";");
                zeneszam = new Zeneszam(adatok[0], adatok[1]);
                zeneSzamModel.addElement(zeneszam);
            }
        }catch (IOException ex) {
            Logger.getLogger(Beolvasas.class.getName()).log(Level.SEVERE, null, ex);
        } 

        return zeneSzamModel;
    }
    
    
}
